<?php
// Version: 2.0; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Gaming Nation Theme.<br /><br />Author: <a href="https://smftricks.com">The SMF Tricks Team</a>';

?>